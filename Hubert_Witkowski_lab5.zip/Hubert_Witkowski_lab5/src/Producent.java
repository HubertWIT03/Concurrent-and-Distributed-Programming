public class Producent implements Runnable {
    private final Bufor bufor;

    public Producent(Bufor bufor) {
        this.bufor = bufor;
    }

    @Override
    public void run() {
        try {
            for (int i = 1; i <= 5; i++) {
                bufor.dodaj(i);
                Thread.sleep((long) (Math.random() * 100));
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}