public class Konsument implements Runnable {
    private final Bufor bufor;

    public Konsument(Bufor bufor) {
        this.bufor = bufor;
    }

    @Override
    public void run() {
        try {
            while (true) {
                int wartosc = bufor.pobierz();
                if (wartosc == -1) {
                    break;
                }
                int kwadrat = wartosc * wartosc;
                System.out.println(Thread.currentThread().getName() + " - Przetworzono: " + wartosc + " (kwadrat: " + kwadrat + ")");
                Thread.sleep((long) (Math.random() * 150));
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}