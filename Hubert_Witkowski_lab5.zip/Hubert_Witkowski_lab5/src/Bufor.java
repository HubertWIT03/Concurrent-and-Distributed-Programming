import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Bufor {
    private final Queue<Integer> kolejka = new LinkedList<>();
    private final int pojemnosc = 5;
    private final Lock lock = new ReentrantLock();
    private final Condition niePusty = lock.newCondition();
    private final Condition niePelny = lock.newCondition();
    private boolean zakonczonoProdukcje = false;

    public void dodaj(int element) throws InterruptedException {
        lock.lock();
        try {
            while (kolejka.size() == pojemnosc) {
                niePelny.await();
            }
            kolejka.add(element);
            System.out.println(Thread.currentThread().getName() + " - Dodano: " + element);
            niePusty.signalAll();
        } finally {
            lock.unlock();
        }
    }

    public int pobierz() throws InterruptedException {
        lock.lock();
        try {
            while (kolejka.isEmpty()) {
                if (zakonczonoProdukcje && kolejka.isEmpty()) {
                    return -1;
                }
                niePusty.await();
            }
            int element = kolejka.remove();
            System.out.println(Thread.currentThread().getName() + " - Pobrano: " + element);
            niePelny.signalAll();
            return element;
        } finally {
            lock.unlock();
        }
    }

    public void zakonczProdukcje() {
        lock.lock();
        try {
            zakonczonoProdukcje = true;
            niePusty.signalAll();
        } finally {
            lock.unlock();
        }
    }
}