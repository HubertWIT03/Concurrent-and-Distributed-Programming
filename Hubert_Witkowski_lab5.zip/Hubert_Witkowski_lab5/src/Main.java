public class Main {
    public static void main(String[] args) {
        Bufor bufor = new Bufor();

        Thread p1 = new Thread(new Producent(bufor), "Producent-1");
        Thread p2 = new Thread(new Producent(bufor), "Producent-2");
        Thread k1 = new Thread(new Konsument(bufor), "Konsument-1");
        Thread k2 = new Thread(new Konsument(bufor), "Konsument-2");

        p1.start();
        p2.start();
        k1.start();
        k2.start();

        try {
            p1.join();
            p2.join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        bufor.zakonczProdukcje();
    }
}