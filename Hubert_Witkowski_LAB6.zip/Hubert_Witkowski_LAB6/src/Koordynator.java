class Koordynator {
    private Fabryka a;
    private Fabryka b;

    public Koordynator(Fabryka a, Fabryka b) {
        this.a = a;
        this.b = b;
    }

    public synchronized int[] pobierzPary() {
        int valA = a.pobierz();

        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
        }

        int valB = b.pobierz();

        return new int[]{valA, valB};
    }
}

