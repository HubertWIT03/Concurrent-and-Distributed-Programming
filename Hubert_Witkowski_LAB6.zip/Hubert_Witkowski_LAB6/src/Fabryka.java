abstract class Fabryka {
    public abstract int pobierz();
}

class FabrykaA extends Fabryka {
    private int licznik = 0;

    public synchronized int pobierz() {
        licznik++;
        return licznik;
    }
}

class FabrykaB extends Fabryka {
    private int licznik = 0;

    public synchronized int pobierz() {
        licznik--;
        return licznik;
    }
}
