class Pracownik implements Runnable {
    private Koordynator koordynator;

    public Pracownik(Koordynator koordynator) {
        this.koordynator = koordynator;
    }

    @Override
    public void run() {
        for (int i = 0; i < 50; i++) {
            int[] para = koordynator.pobierzPary();
            int suma = para[0] + para[1];

            if (suma != 0) {
                System.out.println("Wykryto blad! Para: " + para[0] + ", " + para[1] + " (Suma: " + suma + ")");
            }
        }
    }
}
