
public class Main {
    public static void main(String[] args) {

        Fabryka a = new FabrykaA();
        Fabryka b = new FabrykaB();


        Koordynator koordynator = new Koordynator(a, b);


        int liczbaWatkow = 4;
        Thread[] watki = new Thread[liczbaWatkow];

        System.out.println("Rozpoczynamy testowanie z " + liczbaWatkow + " wątkami...");


        for (int i = 0; i < liczbaWatkow; i++) {
            watki[i] = new Thread(new Pracownik(koordynator));
            watki[i].start();
        }


        for (int i = 0; i < liczbaWatkow; i++) {
            try {
                watki[i].join();
            } catch (InterruptedException e) {

            }
        }

        System.out.println("Zakończono pobieranie danych. Jeśli powyżej nie ma komunikatów o błędach, sekwencja jest bezpieczna!");
    }
}