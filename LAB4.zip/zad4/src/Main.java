import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

class KoordynatorZadan {
    private final Queue<Integer> zadania = new LinkedList<>();
    private boolean dostarczanieZakonczone = false;
    private final Lock lock = new ReentrantLock();
    private final Condition noweZadanie = lock.newCondition();

    public void dodajZadanie(int zadanie) {
        lock.lock();
        try {
            zadania.add(zadanie);
            noweZadanie.signal();
        } finally {
            lock.unlock();
        }
    }

    public void zakonczDostarczanie() {
        lock.lock();
        try {
            dostarczanieZakonczone = true;
            noweZadanie.signalAll();
        } finally {
            lock.unlock();
        }
    }

    public Integer pobierzZadanie() throws InterruptedException {
        lock.lock();
        try {
            while (zadania.isEmpty() && !dostarczanieZakonczone) {
                noweZadanie.await();
            }
            if (zadania.isEmpty() && dostarczanieZakonczone) {
                return null;
            }
            return zadania.poll();
        } finally {
            lock.unlock();
        }
    }
}

class Pracownik implements Runnable {
    private final KoordynatorZadan koordynator;
    private final String nazwa;

    public Pracownik(KoordynatorZadan koordynator, String nazwa) {
        this.koordynator = koordynator;
        this.nazwa = nazwa;
    }

    @Override
    public void run() {
        try {
            while (true) {
                Integer zadanie = koordynator.pobierzZadanie();
                if (zadanie == null) {
                    break;
                }
                System.out.println(nazwa + " przetwarza liczbe: " + zadanie + ", jej kwadrat: " + (zadanie * zadanie));
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}

class Dostawca implements Runnable {
    private final KoordynatorZadan koordynator;

    public Dostawca(KoordynatorZadan koordynator) {
        this.koordynator = koordynator;
    }

    @Override
    public void run() {
        for (int i = 1; i <= 15; i++) {
            koordynator.dodajZadanie(i);
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        koordynator.zakonczDostarczanie();
    }
}

public class Main {
    public static void main(String[] args) {
        KoordynatorZadan koordynator = new KoordynatorZadan();

        Thread p1 = new Thread(new Pracownik(koordynator, "Pracownik 1"));
        Thread p2 = new Thread(new Pracownik(koordynator, "Pracownik 2"));
        Thread p3 = new Thread(new Pracownik(koordynator, "Pracownik 3"));
        Thread dostawca = new Thread(new Dostawca(koordynator));

        p1.start();
        p2.start();
        p3.start();
        dostawca.start();

        try {
            dostawca.join();
            p1.join();
            p2.join();
            p3.join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        System.out.println("Wszystkie operacje zakonczone.");
    }
}